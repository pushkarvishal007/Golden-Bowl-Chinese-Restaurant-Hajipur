import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  INITIAL_GALLERY_IMAGES,
  INITIAL_MENU_ITEMS,
  INITIAL_RESTAURANT_INFO,
} from '../data/initialData';
import {
  GalleryImage,
  MenuItem,
  OrderEnquiry,
  RestaurantInfo,
} from '../types/restaurant';

interface CartItemEntry {
  item: MenuItem;
  quantity: number;
}

interface RestaurantContextType {
  restaurantInfo: RestaurantInfo;
  menuItems: MenuItem[];
  galleryImages: GalleryImage[];
  orderEnquiries: OrderEnquiry[];
  cart: { [id: string]: number };
  cartItems: CartItemEntry[];
  cartTotalCount: number;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addToCart: (item: MenuItem) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  submitOrderEnquiry: (data: {
    customerName: string;
    customerPhone: string;
    preference: 'Pickup Enquiry' | 'Delivery Enquiry';
    notes?: string;
  }) => { enquiry: OrderEnquiry; whatsappUrl: string };
  isAdminOpen: boolean;
  openAdmin: () => void;
  closeAdmin: () => void;
  isAdminAuthenticated: boolean;
  adminPin: string;
  loginAdmin: (pin: string) => boolean;
  logoutAdmin: () => void;
  updateAdminPin: (newPin: string) => boolean;
  updateRestaurantInfo: (updated: Partial<RestaurantInfo>) => void;
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (id: string, updated: Partial<MenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  toggleItemAvailability: (id: string) => void;
  updateEnquiryStatus: (id: string, status: OrderEnquiry['status']) => void;
  deleteOrderEnquiry: (id: string) => void;
  addGalleryImage: (image: Omit<GalleryImage, 'id'>) => void;
  deleteGalleryImage: (id: string) => void;
  resetToDefaults: () => void;
}

const RestaurantContext = createContext<RestaurantContextType | undefined>(undefined);

const STORAGE_KEYS = {
  INFO: 'golden_bowl_info_v1',
  MENU: 'golden_bowl_menu_v1',
  GALLERY: 'golden_bowl_gallery_v1',
  ENQUIRIES: 'golden_bowl_enquiries_v1',
  PIN: 'golden_bowl_pin_v1',
};

const DEFAULT_PIN = '1234';

export const RestaurantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load persistent state or fall back to defaults
  const [restaurantInfo, setRestaurantInfo] = useState<RestaurantInfo>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INFO);
      return saved ? JSON.parse(saved) : INITIAL_RESTAURANT_INFO;
    } catch {
      return INITIAL_RESTAURANT_INFO;
    }
  });

  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MENU);
      return saved ? JSON.parse(saved) : INITIAL_MENU_ITEMS;
    } catch {
      return INITIAL_MENU_ITEMS;
    }
  });

  const [galleryImages, setGalleryImages] = useState<GalleryImage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GALLERY);
      return saved ? JSON.parse(saved) : INITIAL_GALLERY_IMAGES;
    } catch {
      return INITIAL_GALLERY_IMAGES;
    }
  });

  const [orderEnquiries, setOrderEnquiries] = useState<OrderEnquiry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ENQUIRIES);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [adminPin, setAdminPin] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.PIN) || DEFAULT_PIN;
    } catch {
      return DEFAULT_PIN;
    }
  });

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);

  // Cart state
  const [cart, setCart] = useState<{ [id: string]: number }>({});
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INFO, JSON.stringify(restaurantInfo));
    } catch {
      // storage unavailable
    }
  }, [restaurantInfo]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(menuItems));
    } catch {
      // storage unavailable
    }
  }, [menuItems]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(galleryImages));
    } catch {
      // storage unavailable
    }
  }, [galleryImages]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ENQUIRIES, JSON.stringify(orderEnquiries));
    } catch {
      // storage unavailable
    }
  }, [orderEnquiries]);

  // Derived cart items
  const cartItems: CartItemEntry[] = Object.entries(cart)
    .map(([itemId, quantity]) => {
      const item = menuItems.find((m) => m.id === itemId);
      return item ? { item, quantity } : null;
    })
    .filter((entry): entry is CartItemEntry => entry !== null && entry.quantity > 0);

  const cartTotalCount = Object.values(cart).reduce((sum, qty) => sum + qty, 0);

  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);

  const addToCart = (item: MenuItem) => {
    setCart((prev) => ({
      ...prev,
      [item.id]: (prev[item.id] || 0) + 1,
    }));
    setIsCartOpen(true);
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => {
      const next = { ...prev };
      delete next[itemId];
      return next;
    });
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    setCart((prev) => {
      const next = { ...prev };
      if (quantity <= 0) {
        delete next[itemId];
      } else {
        next[itemId] = quantity;
      }
      return next;
    });
  };

  const clearCart = () => {
    setCart({});
  };

  // Submit Order Enquiry Flow & WhatsApp Integration
  const submitOrderEnquiry = (data: {
    customerName: string;
    customerPhone: string;
    preference: 'Pickup Enquiry' | 'Delivery Enquiry';
    notes?: string;
  }) => {
    const itemsList = cartItems.map((ci) => ({
      menuItemId: ci.item.id,
      name: ci.item.name,
      quantity: ci.quantity,
      price: ci.item.price,
    }));

    const newEnquiry: OrderEnquiry = {
      id: `GB-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
      customerName: data.customerName.trim(),
      customerPhone: data.customerPhone.trim(),
      preference: data.preference,
      notes: data.notes?.trim() || undefined,
      items: itemsList,
      status: 'New',
    };

    setOrderEnquiries((prev) => [newEnquiry, ...prev]);

    // Format the items text
    const itemsFormatted = itemsList
      .map((i) => `• ${i.name} × ${i.quantity}`)
      .join('\n');

    // Create the exact message format required
    const message = `Hello Golden Bowl, I would like to enquire about an order.\n\nItems:\n${itemsFormatted}\n\nName: ${newEnquiry.customerName}\nOrder preference: ${newEnquiry.preference}${newEnquiry.notes ? `\nNotes: ${newEnquiry.notes}` : ''}\n\nPlease confirm availability, total price, and order acceptance.`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/918709998972?text=${encodedMessage}`;

    // Clear cart after enquiry creation
    setCart({});

    return { enquiry: newEnquiry, whatsappUrl };
  };

  // Admin controls
  const openAdmin = () => setIsAdminOpen(true);
  const closeAdmin = () => setIsAdminOpen(false);

  const loginAdmin = (pin: string) => {
    if (pin.trim() === adminPin) {
      setIsAdminAuthenticated(true);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
  };

  const updateAdminPin = (newPin: string) => {
    if (newPin.trim().length >= 4) {
      setAdminPin(newPin.trim());
      try {
        localStorage.setItem(STORAGE_KEYS.PIN, newPin.trim());
      } catch {
        // ignore
      }
      return true;
    }
    return false;
  };

  const updateRestaurantInfo = (updated: Partial<RestaurantInfo>) => {
    setRestaurantInfo((prev) => ({ ...prev, ...updated }));
  };

  const addMenuItem = (item: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = {
      ...item,
      id: `gb-${Date.now().toString().slice(-5)}`,
    };
    setMenuItems((prev) => [newItem, ...prev]);
  };

  const updateMenuItem = (id: string, updated: Partial<MenuItem>) => {
    setMenuItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updated } : item))
    );
  };

  const deleteMenuItem = (id: string) => {
    setMenuItems((prev) => prev.filter((item) => item.id !== id));
  };

  const toggleItemAvailability = (id: string) => {
    setMenuItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, isAvailable: !item.isAvailable } : item
      )
    );
  };

  const updateEnquiryStatus = (id: string, status: OrderEnquiry['status']) => {
    setOrderEnquiries((prev) =>
      prev.map((enq) => (enq.id === id ? { ...enq, status } : enq))
    );
  };

  const deleteOrderEnquiry = (id: string) => {
    setOrderEnquiries((prev) => prev.filter((enq) => enq.id !== id));
  };

  const addGalleryImage = (image: Omit<GalleryImage, 'id'>) => {
    const newImage: GalleryImage = {
      ...image,
      id: `gal-${Date.now().toString().slice(-5)}`,
    };
    setGalleryImages((prev) => [newImage, ...prev]);
  };

  const deleteGalleryImage = (id: string) => {
    setGalleryImages((prev) => prev.filter((img) => img.id !== id));
  };

  const resetToDefaults = () => {
    setRestaurantInfo(INITIAL_RESTAURANT_INFO);
    setMenuItems(INITIAL_MENU_ITEMS);
    setGalleryImages(INITIAL_GALLERY_IMAGES);
    setAdminPin(DEFAULT_PIN);
    try {
      localStorage.removeItem(STORAGE_KEYS.INFO);
      localStorage.removeItem(STORAGE_KEYS.MENU);
      localStorage.removeItem(STORAGE_KEYS.GALLERY);
      localStorage.removeItem(STORAGE_KEYS.PIN);
    } catch {
      // ignore
    }
  };

  return (
    <RestaurantContext.Provider
      value={{
        restaurantInfo,
        menuItems,
        galleryImages,
        orderEnquiries,
        cart,
        cartItems,
        cartTotalCount,
        isCartOpen,
        openCart,
        closeCart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        submitOrderEnquiry,
        isAdminOpen,
        openAdmin,
        closeAdmin,
        isAdminAuthenticated,
        adminPin,
        loginAdmin,
        logoutAdmin,
        updateAdminPin,
        updateRestaurantInfo,
        addMenuItem,
        updateMenuItem,
        deleteMenuItem,
        toggleItemAvailability,
        updateEnquiryStatus,
        deleteOrderEnquiry,
        addGalleryImage,
        deleteGalleryImage,
        resetToDefaults,
      }}
    >
      {children}
    </RestaurantContext.Provider>
  );
};

export const useRestaurant = () => {
  const context = useContext(RestaurantContext);
  if (!context) {
    throw new Error('useRestaurant must be used within a RestaurantProvider');
  }
  return context;
};
