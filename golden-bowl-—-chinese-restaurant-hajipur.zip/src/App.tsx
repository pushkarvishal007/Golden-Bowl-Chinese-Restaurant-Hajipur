import { MessageCircle, Phone, ShoppingBag } from 'lucide-react';
import React from 'react';
import { AdminPanel } from './components/AdminPanel';
import { ContactSection } from './components/ContactSection';
import { FoodGallery } from './components/FoodGallery';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { Navbar } from './components/Navbar';
import { OrderEnquiryDrawer } from './components/OrderEnquiryDrawer';
import { OurStory } from './components/OurStory';
import { ReviewsSection } from './components/ReviewsSection';
import { RestaurantProvider, useRestaurant } from './context/RestaurantContext';

const MainLayout: React.FC = () => {
  const { openCart, cartTotalCount, restaurantInfo } = useRestaurant();

  return (
    <div className="min-h-screen bg-[#121212] text-[#F8F4EC] flex flex-col font-sans selection:bg-[#C9A45C] selection:text-[#121212] pb-16 md:pb-0">
      <Navbar />

      <main className="flex-1">
        <Hero />
        <OurStory />
        <MenuSection />
        <FoodGallery />
        <ReviewsSection />
        <ContactSection />
      </main>

      <Footer />

      {/* Floating Order Enquiry & Admin Drawers */}
      <OrderEnquiryDrawer />
      <AdminPanel />

      {/* Mobile-Only Bottom Quick Action Bar (Under 15% viewport height) */}
      <div className="fixed bottom-0 left-0 right-0 z-30 md:hidden bg-[#141414]/95 backdrop-blur-lg border-t border-[#262626] px-4 py-2.5 flex items-center justify-between gap-3 shadow-2xl">
        <a
          href={`tel:${restaurantInfo.phoneRaw}`}
          className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#222222] border border-[#333333] text-xs font-semibold text-[#F8F4EC] active:scale-[0.98]"
        >
          <Phone className="w-3.5 h-3.5 text-[#C9A45C]" />
          <span>Call: {restaurantInfo.phone}</span>
        </a>

        <button
          onClick={openCart}
          className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#C9A45C] text-[#121212] text-xs font-semibold active:scale-[0.98] cursor-pointer"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>Order Enquiry</span>
          {cartTotalCount > 0 && (
            <span className="w-4 h-4 rounded-full bg-[#641E24] text-white text-[10px] flex items-center justify-center font-bold tabular-nums">
              {cartTotalCount}
            </span>
          )}
        </button>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <RestaurantProvider>
      <MainLayout />
    </RestaurantProvider>
  );
}
