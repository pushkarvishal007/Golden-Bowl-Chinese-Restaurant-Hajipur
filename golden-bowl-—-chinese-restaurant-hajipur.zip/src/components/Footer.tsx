import { Lock, Navigation, Phone } from 'lucide-react';
import React from 'react';
import { useRestaurant } from '../context/RestaurantContext';

export const Footer: React.FC = () => {
  const { restaurantInfo, openAdmin } = useRestaurant();

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0D0D0D] border-t border-[#1F1F1F] text-[#F8F4EC]/70 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 items-start text-left">
          {/* Brand & Address Column */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <span className="w-8 h-8 rounded-full border border-[#C9A45C]/50 flex items-center justify-center text-[#C9A45C] text-sm font-serif">
                GB
              </span>
              <span className="text-xl font-serif font-bold text-[#F8F4EC]">
                {restaurantInfo.name}
              </span>
            </div>

            <p className="text-sm text-[#F8F4EC]/75 leading-relaxed max-w-sm">
              Discover delicious Chinese cuisine, flavorful favorites, and welcoming dining at Golden Bowl, Hajipur, Bihar.
            </p>

            <div className="space-y-1 text-xs text-[#F8F4EC]/60">
              <p>{restaurantInfo.address}</p>
              <p>Plus Code: {restaurantInfo.plusCode}</p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#C9A45C]">
              Navigation
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#story" className="hover:text-[#C9A45C] transition-colors">
                  Our Story
                </a>
              </li>
              <li>
                <a href="#menu" className="hover:text-[#C9A45C] transition-colors">
                  Menu & Dishes
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#C9A45C] transition-colors">
                  Food Gallery
                </a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-[#C9A45C] transition-colors">
                  Guest Reviews
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#C9A45C] transition-colors">
                  Location & Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Direct Column */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-[#C9A45C]">
              Direct Contact
            </h4>
            <p className="text-sm text-[#F8F4EC]/80">
              Telephone:
              <a
                href={`tel:${restaurantInfo.phoneRaw}`}
                className="font-semibold text-[#F8F4EC] hover:text-[#C9A45C] ml-1 transition-colors tabular-nums"
              >
                {restaurantInfo.phone}
              </a>
            </p>
            <p className="text-xs text-[#F8F4EC]/60">
              Reported Price Range: {restaurantInfo.priceRange}
            </p>
            <div className="pt-2">
              <a
                href={restaurantInfo.directionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-[#C9A45C] hover:underline"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Open Google Maps Directions</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-[#1C1C1C] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#F8F4EC]/50">
          <p>© {currentYear} {restaurantInfo.name}. All rights reserved.</p>

          <div className="flex items-center gap-4">
            <span className="text-[11px] text-[#F8F4EC]/40">
              All content in English
            </span>
            <span aria-hidden="true">·</span>
            <button
              onClick={openAdmin}
              className="inline-flex items-center gap-1 text-[11px] text-[#F8F4EC]/40 hover:text-[#C9A45C] transition-colors cursor-pointer"
            >
              <Lock className="w-3 h-3" />
              <span>Owner Portal</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
