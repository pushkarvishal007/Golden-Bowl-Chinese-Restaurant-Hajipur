import {
  Clock,
  ExternalLink,
  MapPin,
  MessageCircle,
  Navigation,
  Phone,
} from 'lucide-react';
import React from 'react';
import { useRestaurant } from '../context/RestaurantContext';

export const ContactSection: React.FC = () => {
  const { restaurantInfo } = useRestaurant();

  const generalWhatsappUrl = `https://wa.me/918709998972?text=${encodeURIComponent(
    'Hello Golden Bowl, I have an enquiry regarding dining or takeaway.'
  )}`;

  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#151515] border-t border-[#242424]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C9A45C]">
            <span>Visit Us & Connect</span>
            <span aria-hidden="true">·</span>
            <span>Hajipur, Bihar</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-[#F8F4EC] tracking-tight [text-wrap:balance]">
            Location & Contact
          </h2>

          <p className="text-base text-[#F8F4EC]/75 leading-relaxed font-normal">
            Whether you are planning to dine in, enquire about our menu, or pick up your favorites, we look forward to welcoming you at Golden Bowl.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Contact Details Card */}
          <div className="lg:col-span-5 bg-[#181818] border border-[#2D2D2D] rounded-3xl p-7 sm:p-8 flex flex-col justify-between space-y-8 text-left shadow-xl">
            <div className="space-y-6">
              <div>
                <span className="text-xs uppercase font-semibold text-[#C9A45C] tracking-wider block mb-1">
                  Restaurant
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#F8F4EC]">
                  {restaurantInfo.name}
                </h3>
                <p className="text-xs text-[#C9A45C] mt-0.5">
                  {restaurantInfo.category} · Hajipur
                </p>
              </div>

              {/* Physical Address */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C] shrink-0 mt-0.5">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs uppercase font-semibold tracking-wider text-[#F8F4EC]/50">
                    Address
                  </h4>
                  <p className="text-sm sm:text-base font-medium text-[#F8F4EC] mt-1 leading-snug">
                    {restaurantInfo.address}
                  </p>
                  <p className="text-xs text-[#F8F4EC]/65 mt-1 font-mono">
                    Google Plus Code: {restaurantInfo.plusCode}
                  </p>
                </div>
              </div>

              {/* Telephone */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C] shrink-0 mt-0.5">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs uppercase font-semibold tracking-wider text-[#F8F4EC]/50">
                    Phone Number
                  </h4>
                  <a
                    href={`tel:${restaurantInfo.phoneRaw}`}
                    className="text-base font-semibold text-[#F8F4EC] hover:text-[#C9A45C] transition-colors mt-1 block tabular-nums"
                  >
                    {restaurantInfo.phone}
                  </a>
                  <span className="text-xs text-[#F8F4EC]/60 block mt-0.5">
                    Available for dine-in questions & takeaway enquiries
                  </span>
                </div>
              </div>

              {/* Opening Hours Status (Editable & Un-invented) */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C] shrink-0 mt-0.5">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs uppercase font-semibold tracking-wider text-[#F8F4EC]/50">
                    Opening Hours
                  </h4>
                  <p className="text-sm font-medium text-[#C9A45C] mt-1">
                    {restaurantInfo.openingHoursStatus}
                  </p>
                  <p className="text-xs text-[#F8F4EC]/65 mt-1 leading-relaxed">
                    {restaurantInfo.openingHoursNote}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Contact Buttons */}
            <div className="space-y-3 pt-4 border-t border-[#262626]">
              <a
                href={`tel:${restaurantInfo.phoneRaw}`}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-xl transition-all shadow-md active:scale-[0.98]"
              >
                <Phone className="w-4 h-4" />
                <span>Call Now: {restaurantInfo.phone}</span>
              </a>

              <div className="grid grid-cols-2 gap-3">
                <a
                  href={generalWhatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#222222] hover:bg-[#25D366] hover:text-black border border-[#3A3A3A] rounded-xl transition-all active:scale-[0.98]"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp Enquiry</span>
                </a>

                <a
                  href={restaurantInfo.directionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#F8F4EC] bg-[#222222] hover:bg-[#2F2F2F] border border-[#3A3A3A] hover:border-[#C9A45C] rounded-xl transition-all active:scale-[0.98]"
                >
                  <Navigation className="w-4 h-4 text-[#C9A45C]" />
                  <span>Get Directions</span>
                </a>
              </div>
            </div>
          </div>

          {/* Interactive Directions / Map Canvas Card */}
          <div className="lg:col-span-7 bg-[#181818] border border-[#2D2D2D] rounded-3xl overflow-hidden flex flex-col justify-between shadow-xl">
            {/* Visual Map Overview Container */}
            <div className="relative flex-1 min-h-[300px] sm:min-h-[380px] bg-[#202020] flex items-center justify-center overflow-hidden">
              {/* Background ambient restaurant shot overlay */}
              <img
                src="/src/assets/images/restaurant_interior_warm_1791946786520.jpg"
                alt="Golden Bowl restaurant location in Hajipur"
                className="absolute inset-0 w-full h-full object-cover filter brightness-[0.25] contrast-[1.1]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-black/40 to-black/60" />

              {/* Pin Center Card */}
              <div className="relative z-10 max-w-sm w-full mx-4 p-6 rounded-2xl bg-[#121212]/90 border border-[#3A3A3A] backdrop-blur-md text-center space-y-3 shadow-2xl">
                <div className="w-12 h-12 rounded-full bg-[#C9A45C]/20 border border-[#C9A45C] flex items-center justify-center text-[#C9A45C] mx-auto animate-bounce">
                  <MapPin className="w-6 h-6" />
                </div>
                <h4 className="font-serif text-lg font-semibold text-[#F8F4EC]">
                  Golden Bowl
                </h4>
                <p className="text-xs text-[#F8F4EC]/80 leading-relaxed">
                  Ramsagar Singh Complex, Kachahari Road, Hajipur, Bihar 844101
                </p>
                <div className="pt-1 flex items-center justify-center gap-2">
                  <span className="text-[11px] font-mono text-[#C9A45C] bg-[#222222] px-2 py-0.5 rounded border border-[#333333]">
                    Plus Code: M6R6+Q2
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Map Action Bar */}
            <div className="p-6 bg-[#161616] border-t border-[#262626] flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
              <div>
                <p className="text-xs font-semibold text-[#F8F4EC] uppercase tracking-wider">
                  Navigation Route
                </p>
                <p className="text-xs text-[#F8F4EC]/60 mt-0.5">
                  Open Google Maps for turn-by-turn navigation directly to Golden Bowl.
                </p>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <a
                  href={restaurantInfo.directionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-xl transition-all shadow-sm"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Open Directions</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <a
                  href={restaurantInfo.mapsSearchUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-[#F8F4EC] bg-[#222222] hover:bg-[#2A2A2A] border border-[#333333] rounded-xl transition-colors"
                >
                  <span>View on Maps</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
