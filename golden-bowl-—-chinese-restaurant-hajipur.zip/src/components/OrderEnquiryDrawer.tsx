import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  MessageCircle,
  Minus,
  Phone,
  Plus,
  Trash2,
  X,
} from 'lucide-react';
import React, { useState } from 'react';
import { useRestaurant } from '../context/RestaurantContext';
import { OrderEnquiry } from '../types/restaurant';

export const OrderEnquiryDrawer: React.FC = () => {
  const {
    isCartOpen,
    closeCart,
    cartItems,
    updateQuantity,
    removeFromCart,
    clearCart,
    submitOrderEnquiry,
    restaurantInfo,
  } = useRestaurant();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [preference, setPreference] = useState<'Pickup Enquiry' | 'Delivery Enquiry'>(
    'Pickup Enquiry'
  );
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [submittedEnquiry, setSubmittedEnquiry] = useState<{
    enquiry: OrderEnquiry;
    whatsappUrl: string;
  } | null>(null);

  if (!isCartOpen) return null;

  const validatePhone = (phone: string) => {
    // Basic validation for 10-digit Indian number (with optional +91 or leading 0)
    const cleaned = phone.replace(/\D/g, '');
    return cleaned.length >= 10 && cleaned.length <= 13;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (cartItems.length === 0) {
      setErrorMsg('Please select at least one item from the menu to enquire.');
      return;
    }

    if (!customerName.trim()) {
      setErrorMsg('Please provide your name so the restaurant can address you.');
      return;
    }

    if (!validatePhone(customerPhone)) {
      setErrorMsg('Please provide a valid 10-digit mobile contact number.');
      return;
    }

    const result = submitOrderEnquiry({
      customerName,
      customerPhone,
      preference,
      notes,
    });

    setSubmittedEnquiry(result);

    // Open WhatsApp in a new tab if supported
    window.open(result.whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  const handleReset = () => {
    setSubmittedEnquiry(null);
    setCustomerName('');
    setCustomerPhone('');
    setNotes('');
    closeCart();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/75 backdrop-blur-xs transition-opacity"
        onClick={closeCart}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#161616] border-l border-[#2E2E2E] flex flex-col shadow-2xl">
          {/* Header */}
          <div className="px-6 py-5 border-b border-[#262626] flex items-center justify-between">
            <div>
              <h3 className="font-serif text-xl font-semibold text-[#F8F4EC]">
                Order Enquiry
              </h3>
              <p className="text-xs text-[#C9A45C]">Golden Bowl · Hajipur</p>
            </div>
            <button
              onClick={closeCart}
              className="p-2 text-[#F8F4EC]/60 hover:text-[#F8F4EC] rounded-lg transition-colors"
              aria-label="Close Enquiry Drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {submittedEnquiry ? (
              /* Success / Enquiry Submitted State */
              <div className="space-y-6 py-4 text-left">
                <div className="w-12 h-12 rounded-full bg-[#107C41]/20 border border-[#107C41] flex items-center justify-center text-[#107C41]">
                  <CheckCircle2 className="w-6 h-6" />
                </div>

                <div className="space-y-2">
                  <h4 className="font-serif text-2xl font-semibold text-[#F8F4EC]">
                    Enquiry Recorded
                  </h4>
                  <p className="text-xs text-[#C9A45C] font-mono">
                    Ref ID: {submittedEnquiry.enquiry.id}
                  </p>
                  <p className="text-sm text-[#F8F4EC]/80 leading-relaxed">
                    Your enquiry details have been generated. We opened WhatsApp with the formatted order request for Golden Bowl.
                  </p>
                </div>

                {/* Clear Disclaimer as requested */}
                <div className="bg-[#1F1F1F] border border-[#333333] p-4 rounded-xl space-y-2 text-xs text-[#F8F4EC]/75">
                  <div className="flex items-center gap-1.5 font-medium text-[#C9A45C]">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>Important Order Notice</span>
                  </div>
                  <p className="leading-relaxed">
                    This submission is an <strong>order enquiry</strong>. An order is confirmed only after Golden Bowl's staff confirms item availability, total price, and accepts your order.
                  </p>
                </div>

                {/* Summary of what was requested */}
                <div className="bg-[#121212] p-4 rounded-xl border border-[#262626] space-y-2">
                  <span className="text-xs uppercase font-medium text-[#F8F4EC]/50 tracking-wider block">
                    Enquired Items
                  </span>
                  <ul className="divide-y divide-[#222222] text-xs">
                    {submittedEnquiry.enquiry.items.map((item, idx) => (
                      <li key={idx} className="py-2 flex justify-between">
                        <span className="text-[#F8F4EC]">
                          {item.name} × {item.quantity}
                        </span>
                        <span className="text-[#F8F4EC]/60">
                          {item.price ? `₹${item.price * item.quantity}` : 'Price on confirmation'}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <div className="pt-2 border-t border-[#222222] text-xs text-[#F8F4EC]/60 flex justify-between">
                    <span>Preference:</span>
                    <span className="text-[#F8F4EC] font-medium">
                      {submittedEnquiry.enquiry.preference}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="space-y-3 pt-2">
                  <a
                    href={submittedEnquiry.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#25D366] text-black font-semibold text-sm hover:bg-[#20bd5a] transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Re-open WhatsApp Message</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>

                  <a
                    href={`tel:${restaurantInfo.phoneRaw}`}
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#222222] border border-[#3A3A3A] text-[#F8F4EC] font-medium text-sm hover:border-[#C9A45C] transition-colors"
                  >
                    <Phone className="w-4 h-4 text-[#C9A45C]" />
                    <span>Call Golden Bowl Directly: {restaurantInfo.phone}</span>
                  </a>

                  <button
                    onClick={handleReset}
                    className="w-full py-2.5 text-xs text-[#F8F4EC]/50 hover:text-[#F8F4EC] transition-colors"
                  >
                    Start a New Enquiry
                  </button>
                </div>
              </div>
            ) : cartItems.length === 0 ? (
              /* Empty Cart State */
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#202020] border border-[#2D2D2D] flex items-center justify-center mx-auto text-[#C9A45C]/60">
                  <MessageCircle className="w-8 h-8" />
                </div>
                <h4 className="font-serif text-lg font-semibold text-[#F8F4EC]">
                  Your Enquiry is Empty
                </h4>
                <p className="text-xs text-[#F8F4EC]/65 max-w-xs mx-auto leading-relaxed">
                  Browse our menu and click "Add to Enquiry" on any item to build your enquiry list.
                </p>
                <button
                  onClick={closeCart}
                  className="mt-2 inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-colors cursor-pointer"
                >
                  <span>Browse Menu</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              /* Cart with Selected Items & Customer Form */
              <div className="space-y-6 text-left">
                {/* Itemized List */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#F8F4EC]/60 uppercase tracking-wider">
                    <span>Selected Items ({cartItems.length})</span>
                    <button
                      onClick={clearCart}
                      className="text-[#F8F4EC]/40 hover:text-[#A4262C] transition-colors"
                    >
                      Clear all
                    </button>
                  </div>

                  <div className="divide-y divide-[#242424] border border-[#282828] rounded-xl overflow-hidden bg-[#131313]">
                    {cartItems.map(({ item, quantity }) => (
                      <div key={item.id} className="p-3.5 flex items-center justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <h5 className="text-sm font-semibold text-[#F8F4EC] truncate">
                            {item.name}
                          </h5>
                          <span className="text-xs text-[#C9A45C]">
                            {item.price ? `₹${item.price} each` : 'Price on confirmation'}
                          </span>
                        </div>

                        {/* Quantity Stepper */}
                        <div className="flex items-center gap-2 bg-[#1C1C1C] border border-[#2D2D2D] rounded-lg px-2 py-1">
                          <button
                            onClick={() => updateQuantity(item.id, quantity - 1)}
                            className="text-[#F8F4EC]/60 hover:text-[#F8F4EC] p-0.5"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-semibold text-[#F8F4EC] w-4 text-center tabular-nums">
                            {quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, quantity + 1)}
                            className="text-[#F8F4EC]/60 hover:text-[#F8F4EC] p-0.5"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Remove item */}
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-[#F8F4EC]/40 hover:text-[#A4262C] transition-colors p-1"
                          aria-label={`Remove ${item.name}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Customer Details Form */}
                <form onSubmit={handleSubmit} className="space-y-4 pt-2">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-[#F8F4EC]/80 block">
                      Your Full Name <span className="text-[#C9A45C]">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Rajesh Sharma"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#1B1B1B] border border-[#2E2E2E] rounded-lg text-sm text-[#F8F4EC] placeholder-[#F8F4EC]/35 focus:outline-none focus:border-[#C9A45C] transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-[#F8F4EC]/80 block">
                      Phone Number <span className="text-[#C9A45C]">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g., 9876543210"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#1B1B1B] border border-[#2E2E2E] rounded-lg text-sm text-[#F8F4EC] placeholder-[#F8F4EC]/35 focus:outline-none focus:border-[#C9A45C] transition-colors"
                    />
                    <span className="text-[11px] text-[#F8F4EC]/50 block">
                      Used by Golden Bowl to confirm your enquiry.
                    </span>
                  </div>

                  {/* Order Preference */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-[#F8F4EC]/80 block">
                      Order Preference <span className="text-[#C9A45C]">*</span>
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setPreference('Pickup Enquiry')}
                        className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                          preference === 'Pickup Enquiry'
                            ? 'bg-[#C9A45C] text-[#121212] font-semibold border-[#C9A45C]'
                            : 'bg-[#1B1B1B] text-[#F8F4EC]/75 border-[#2E2E2E] hover:border-[#444444]'
                        }`}
                      >
                        Pickup Enquiry
                      </button>
                      <button
                        type="button"
                        onClick={() => setPreference('Delivery Enquiry')}
                        className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-colors cursor-pointer ${
                          preference === 'Delivery Enquiry'
                            ? 'bg-[#C9A45C] text-[#121212] font-semibold border-[#C9A45C]'
                            : 'bg-[#1B1B1B] text-[#F8F4EC]/75 border-[#2E2E2E] hover:border-[#444444]'
                        }`}
                      >
                        Delivery Enquiry
                      </button>
                    </div>
                  </div>

                  {/* Special Notes */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-[#F8F4EC]/80 block">
                      Special Notes (Optional)
                    </label>
                    <textarea
                      rows={2}
                      placeholder="e.g., Less spicy, extra sauce, or desired time..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full px-3.5 py-2 bg-[#1B1B1B] border border-[#2E2E2E] rounded-lg text-xs text-[#F8F4EC] placeholder-[#F8F4EC]/35 focus:outline-none focus:border-[#C9A45C] transition-colors resize-none"
                    />
                  </div>

                  {/* Error display */}
                  {errorMsg && (
                    <div className="p-3 bg-[#641E24]/30 border border-[#641E24] rounded-lg text-xs text-red-200">
                      {errorMsg}
                    </div>
                  )}

                  {/* Notice about Enquiry & WhatsApp */}
                  <div className="bg-[#1C1C1C] border border-[#2C2C2C] p-3.5 rounded-xl space-y-1.5 text-[11px] text-[#F8F4EC]/70 leading-relaxed">
                    <p className="font-medium text-[#C9A45C]">
                      Enquiry Submission Notice:
                    </p>
                    <p>
                      Submitting will register your enquiry and open WhatsApp with the formatted request to Golden Bowl (+91 87099 98972) to confirm availability and total price.
                    </p>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full flex items-center justify-center gap-2 py-3.5 px-4 text-sm font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-xl transition-all shadow-md active:scale-[0.98] cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Submit Order Enquiry via WhatsApp</span>
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
