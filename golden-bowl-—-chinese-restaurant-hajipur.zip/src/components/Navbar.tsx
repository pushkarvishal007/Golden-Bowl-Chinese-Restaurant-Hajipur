import { Menu, Phone, ShoppingBag, X } from 'lucide-react';
import React, { useState } from 'react';
import { useRestaurant } from '../context/RestaurantContext';

export const Navbar: React.FC = () => {
  const { restaurantInfo, cartTotalCount, openCart, openAdmin } = useRestaurant();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Our Story', href: '#story' },
    { label: 'Menu', href: '#menu' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#121212]/95 backdrop-blur-md border-b border-[#252525] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          {/* Zone 1: Brand Wordmark (Single text element) */}
          <a
            href="#"
            className="flex items-center gap-3 text-xl sm:text-2xl font-serif tracking-tight text-[#F8F4EC] whitespace-nowrap shrink-0 hover:text-[#C9A45C] transition-colors"
          >
            <span className="w-8 h-8 rounded-full border border-[#C9A45C]/50 flex items-center justify-center text-[#C9A45C] text-sm font-serif">
              GB
            </span>
            <span>{restaurantInfo.name}</span>
          </a>

          {/* Zone 2: Navigation Links (Clean single-line text links) */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-[#F8F4EC]/80">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className="whitespace-nowrap shrink-0 hover:text-[#C9A45C] transition-colors relative py-1 text-sm tracking-wide"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 Primary Action + Cart/Phone Action */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Quick Call icon link */}
            <a
              href={`tel:${restaurantInfo.phoneRaw}`}
              aria-label="Call Golden Bowl"
              className="hidden sm:inline-flex items-center justify-center w-10 h-10 rounded-lg border border-[#333333] text-[#F8F4EC]/80 hover:text-[#C9A45C] hover:border-[#C9A45C]/50 transition-colors"
            >
              <Phone className="w-4 h-4" />
            </a>

            {/* Primary Order Now CTA with Enquiry Cart Count */}
            <button
              onClick={openCart}
              className="relative inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium tracking-wide text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-all shadow-sm active:scale-[0.98] whitespace-nowrap shrink-0 font-sans cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Order Now</span>
              {cartTotalCount > 0 && (
                <span className="inline-flex items-center justify-center w-5 h-5 text-[11px] font-bold text-white bg-[#641E24] rounded-full tabular-nums">
                  {cartTotalCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle Navigation Menu"
              className="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg border border-[#333333] text-[#F8F4EC] hover:text-[#C9A45C] transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Accessible Mobile Slide-Out Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-[#252525] bg-[#161616] px-4 pt-4 pb-6 space-y-4 animate-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className="text-base font-medium text-[#F8F4EC]/90 hover:text-[#C9A45C] transition-colors py-1.5 border-b border-[#222222]"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-2 flex flex-col gap-2.5">
            <a
              href={`tel:${restaurantInfo.phoneRaw}`}
              className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-lg border border-[#333333] text-sm text-[#F8F4EC] hover:border-[#C9A45C]/60 transition-colors"
            >
              <Phone className="w-4 h-4 text-[#C9A45C]" />
              <span>Call: {restaurantInfo.phone}</span>
            </a>

            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                openAdmin();
              }}
              className="text-xs text-left text-[#F8F4EC]/40 hover:text-[#C9A45C] transition-colors py-1"
            >
              Owner Portal Login
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
