import { ArrowDownRight, MapPin, Navigation, Phone, Star, UtensilsCrossed } from 'lucide-react';
import React from 'react';
import { useRestaurant } from '../context/RestaurantContext';

export const Hero: React.FC = () => {
  const { restaurantInfo } = useRestaurant();

  const scrollToMenu = () => {
    const menuEl = document.getElementById('menu');
    if (menuEl) {
      menuEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[90vh] lg:min-h-[92vh] flex items-center justify-center overflow-hidden bg-[#121212]">
      {/* Background Cinematic Food Photography with Measured Gradient Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_chinese_culinary_1791946784014.jpg"
          alt="Wok tossing noodles and sizzling Chinese cuisine at Golden Bowl"
          className="w-full h-full object-cover object-center filter brightness-[0.45] contrast-[1.08] scale-105 transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/60 to-black/75" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(18,18,18,0.7)_100%)]" />
      </div>

      <div className="relative z-10 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Main Hero Editorial Column */}
          <div className="lg:col-span-7 xl:col-span-8 space-y-6 sm:space-y-8 text-left">
            {/* Elegant brand kicker (Unboxed text with subtle separator) */}
            <div className="flex items-center gap-2 text-xs sm:text-sm font-medium tracking-widest text-[#C9A45C] uppercase">
              <span>{restaurantInfo.category}</span>
              <span aria-hidden="true">·</span>
              <span>Hajipur, Bihar</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-serif font-semibold text-[#F8F4EC] leading-[1.12] tracking-tight max-w-3xl [text-wrap:balance]">
              {restaurantInfo.heroHeadline}
            </h1>

            {/* Supporting Prose */}
            <p className="text-base sm:text-lg lg:text-xl text-[#F8F4EC]/85 max-w-2xl font-normal leading-relaxed">
              {restaurantInfo.heroSubheadline}
            </p>

            {/* CTAs: All perform real functional actions */}
            <div className="pt-2 flex flex-wrap items-center gap-4 sm:gap-5">
              <button
                onClick={scrollToMenu}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold tracking-wide text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-all shadow-lg shadow-[#C9A45C]/15 active:scale-[0.98] cursor-pointer"
              >
                <span>Explore Our Menu</span>
                <ArrowDownRight className="w-4 h-4" />
              </button>

              <a
                href={`tel:${restaurantInfo.phoneRaw}`}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold tracking-wide text-[#F8F4EC] bg-[#1E1E1E]/90 hover:bg-[#2A2A2A] border border-[#3A3A3A] hover:border-[#C9A45C]/50 rounded-lg transition-all shadow-sm active:scale-[0.98]"
              >
                <Phone className="w-4 h-4 text-[#C9A45C]" />
                <span>Call to Order</span>
              </a>

              <a
                href={restaurantInfo.directionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-medium tracking-wide text-[#F8F4EC]/80 hover:text-[#C9A45C] hover:bg-white/5 rounded-lg transition-all"
              >
                <Navigation className="w-4 h-4 text-[#C9A45C]" />
                <span>Get Directions</span>
              </a>
            </div>
          </div>

          {/* Floating Restaurant Information Card (Desktop & Tablet) */}
          <div className="lg:col-span-5 xl:col-span-4">
            <div className="bg-[#181818]/90 backdrop-blur-xl border border-[#2F2F2F] rounded-2xl p-6 sm:p-7 shadow-2xl text-left space-y-5">
              <div className="flex items-start justify-between border-b border-[#2A2A2A] pb-4">
                <div>
                  <h3 className="font-serif text-xl font-semibold text-[#F8F4EC]">
                    {restaurantInfo.name}
                  </h3>
                  <p className="text-xs text-[#C9A45C] mt-0.5 tracking-wide">
                    {restaurantInfo.category}
                  </p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 text-[#C9A45C]">
                    <Star className="w-4 h-4 fill-[#C9A45C]" />
                    <span className="font-semibold text-sm tabular-nums text-[#F8F4EC]">
                      {restaurantInfo.ratingReference}
                    </span>
                    <span className="text-xs text-[#F8F4EC]/60">/ 5</span>
                  </div>
                  <span className="text-[11px] text-[#F8F4EC]/60 block tabular-nums">
                    ({restaurantInfo.reviewCountReference} reviews)*
                  </span>
                </div>
              </div>

              {/* Location & Details */}
              <div className="space-y-3.5 text-xs sm:text-sm text-[#F8F4EC]/80">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#C9A45C] shrink-0 mt-0.5" />
                  <div>
                    <p className="text-[#F8F4EC] font-medium leading-snug">
                      {restaurantInfo.address}
                    </p>
                    <p className="text-xs text-[#F8F4EC]/60 mt-0.5">
                      Plus Code: {restaurantInfo.plusCode}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-[#C9A45C] shrink-0" />
                  <a
                    href={`tel:${restaurantInfo.phoneRaw}`}
                    className="hover:text-[#C9A45C] transition-colors tabular-nums font-medium text-[#F8F4EC]"
                  >
                    {restaurantInfo.phone}
                  </a>
                </div>

                <div className="flex items-center gap-3">
                  <UtensilsCrossed className="w-4 h-4 text-[#C9A45C] shrink-0" />
                  <span className="text-[#F8F4EC]/90">
                    Reported price range: <span className="font-medium text-[#F8F4EC]">{restaurantInfo.priceRange}</span>
                  </span>
                </div>
              </div>

              {/* Operating status banner note */}
              <div className="pt-2 border-t border-[#2A2A2A] text-xs space-y-1">
                <div className="flex items-center justify-between text-[#C9A45C]">
                  <span className="font-medium">{restaurantInfo.openingHoursStatus}</span>
                </div>
                <p className="text-[11px] text-[#F8F4EC]/60 leading-relaxed">
                  {restaurantInfo.openingHoursNote}
                </p>
                <p className="text-[10px] text-[#F8F4EC]/45 italic pt-1">
                  *{restaurantInfo.ratingNote}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
