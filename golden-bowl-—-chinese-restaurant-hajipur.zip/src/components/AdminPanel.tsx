import {
  AlertCircle,
  Check,
  CheckCircle2,
  Clock,
  Edit2,
  ExternalLink,
  Eye,
  EyeOff,
  Image as ImageIcon,
  Key,
  Lock,
  LogOut,
  MessageCircle,
  Phone,
  Plus,
  RefreshCw,
  ShoppingBag,
  Trash2,
  UtensilsCrossed,
  X,
} from 'lucide-react';
import React, { useState } from 'react';
import { useRestaurant } from '../context/RestaurantContext';
import { MenuCategory, MenuItem, OrderEnquiry } from '../types/restaurant';

export const AdminPanel: React.FC = () => {
  const {
    isAdminOpen,
    closeAdmin,
    isAdminAuthenticated,
    loginAdmin,
    logoutAdmin,
    updateAdminPin,
    restaurantInfo,
    updateRestaurantInfo,
    menuItems,
    addMenuItem,
    updateMenuItem,
    deleteMenuItem,
    toggleItemAvailability,
    orderEnquiries,
    updateEnquiryStatus,
    deleteOrderEnquiry,
    galleryImages,
    addGalleryImage,
    deleteGalleryImage,
    resetToDefaults,
  } = useRestaurant();

  const [activeTab, setActiveTab] = useState<'orders' | 'menu' | 'info' | 'gallery' | 'settings'>(
    'orders'
  );
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');

  // Editing dish state
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [isAddingItem, setIsAddingItem] = useState(false);

  // New item form state
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState<MenuCategory>('Chinese Starters');
  const [itemPrice, setItemPrice] = useState<string>('');
  const [itemDesc, setItemDesc] = useState('');
  const [itemVeg, setItemVeg] = useState<boolean | null>(true);
  const [itemImage, setItemImage] = useState('/src/assets/images/chinese_starters_dish_1791946785620.jpg');
  const [itemPopular, setItemPopular] = useState(false);

  // Restaurant info form state
  const [infoForm, setInfoForm] = useState({ ...restaurantInfo });

  // Gallery add form state
  const [newImageTitle, setNewImageTitle] = useState('');
  const [newImageCat, setNewImageCat] = useState('Culinary Craft');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newImageCaption, setNewImageCaption] = useState('');

  // Change PIN state
  const [newPin, setNewPin] = useState('');
  const [pinSuccess, setPinSuccess] = useState(false);

  if (!isAdminOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    const success = loginAdmin(pinInput);
    if (!success) {
      setPinError('Incorrect Owner PIN. (Default is 1234)');
    } else {
      setPinInput('');
    }
  };

  const handleSaveInfo = (e: React.FormEvent) => {
    e.preventDefault();
    updateRestaurantInfo(infoForm);
    alert('Restaurant details updated successfully.');
  };

  const handleCreateOrUpdateItem = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedPrice = itemPrice.trim() !== '' ? Number(itemPrice) : null;

    if (editingItem) {
      updateMenuItem(editingItem.id, {
        name: itemName,
        category: itemCategory,
        price: parsedPrice,
        description: itemDesc,
        isVeg: itemVeg,
        image: itemImage,
        isPopular: itemPopular,
      });
      setEditingItem(null);
    } else {
      addMenuItem({
        name: itemName,
        category: itemCategory,
        price: parsedPrice,
        description: itemDesc,
        isVeg: itemVeg,
        image: itemImage,
        isAvailable: true,
        isPopular: itemPopular,
      });
      setIsAddingItem(false);
    }

    // Reset form
    setItemName('');
    setItemPrice('');
    setItemDesc('');
  };

  const startEditItem = (item: MenuItem) => {
    setEditingItem(item);
    setIsAddingItem(false);
    setItemName(item.name);
    setItemCategory(item.category);
    setItemPrice(item.price !== null ? String(item.price) : '');
    setItemDesc(item.description);
    setItemVeg(item.isVeg);
    setItemImage(item.image);
    setItemPopular(!!item.isPopular);
  };

  const startAddItem = () => {
    setEditingItem(null);
    setIsAddingItem(true);
    setItemName('');
    setItemCategory('Chinese Starters');
    setItemPrice('');
    setItemDesc('');
    setItemVeg(true);
    setItemImage('/src/assets/images/chinese_starters_dish_1791946785620.jpg');
    setItemPopular(false);
  };

  const handleAddGalleryImage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newImageUrl.trim() || !newImageTitle.trim()) return;

    addGalleryImage({
      title: newImageTitle.trim(),
      category: newImageCat.trim(),
      imageUrl: newImageUrl.trim(),
      caption: newImageCaption.trim(),
    });

    setNewImageTitle('');
    setNewImageUrl('');
    setNewImageCaption('');
  };

  const handlePinChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.trim().length >= 4) {
      updateAdminPin(newPin.trim());
      setPinSuccess(true);
      setNewPin('');
      setTimeout(() => setPinSuccess(false), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div className="relative w-full max-w-5xl bg-[#161616] border border-[#2D2D2D] rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="p-5 sm:px-8 border-b border-[#262626] flex items-center justify-between bg-[#131313]">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-xl bg-[#C9A45C]/15 text-[#C9A45C]">
              <Lock className="w-5 h-5" />
            </span>
            <div>
              <h3 className="font-serif text-lg sm:text-xl font-semibold text-[#F8F4EC]">
                Owner Portal · Golden Bowl
              </h3>
              <p className="text-xs text-[#C9A45C]">
                {isAdminAuthenticated ? 'Authenticated Access' : 'Security Verification'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAdminAuthenticated && (
              <button
                onClick={logoutAdmin}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#F8F4EC]/60 hover:text-[#A4262C] hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                title="Log Out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Log Out</span>
              </button>
            )}

            <button
              onClick={closeAdmin}
              className="p-2 text-[#F8F4EC]/60 hover:text-[#F8F4EC] rounded-lg transition-colors cursor-pointer"
              aria-label="Close Admin Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* If Not Authenticated -> Login Prompt */}
        {!isAdminAuthenticated ? (
          <div className="p-8 sm:p-12 max-w-md mx-auto w-full text-center space-y-6">
            <div className="w-14 h-14 rounded-2xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C] mx-auto">
              <Key className="w-6 h-6" />
            </div>

            <div className="space-y-2">
              <h4 className="font-serif text-2xl font-semibold text-[#F8F4EC]">
                Owner Authentication
              </h4>
              <p className="text-xs sm:text-sm text-[#F8F4EC]/70">
                Enter your owner PIN to manage dishes, view customer order enquiries, and edit restaurant information.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="password"
                maxLength={8}
                placeholder="Enter PIN (Default: 1234)"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                autoFocus
                className="w-full text-center tracking-widest text-xl px-4 py-3 bg-[#1C1C1C] border border-[#333333] rounded-xl text-[#F8F4EC] placeholder-[#F8F4EC]/30 focus:outline-none focus:border-[#C9A45C]"
              />

              {pinError && (
                <p className="text-xs text-red-400 font-medium">{pinError}</p>
              )}

              <button
                type="submit"
                className="w-full py-3 px-4 text-sm font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-xl transition-all shadow-md active:scale-[0.98] cursor-pointer"
              >
                Access Dashboard
              </button>
            </form>

            <p className="text-[11px] text-[#F8F4EC]/40">
              *Default initial owner PIN is <code className="text-[#C9A45C]">1234</code>. You can change this PIN once inside.
            </p>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Tabs Navigation */}
            <div className="flex items-center gap-1 px-4 sm:px-8 border-b border-[#242424] bg-[#141414] overflow-x-auto min-w-max">
              <button
                onClick={() => setActiveTab('orders')}
                className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'orders'
                    ? 'border-[#C9A45C] text-[#C9A45C] font-semibold'
                    : 'border-transparent text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Order Enquiries</span>
                {orderEnquiries.filter((o) => o.status === 'New').length > 0 && (
                  <span className="w-5 h-5 rounded-full bg-[#641E24] text-white text-[11px] flex items-center justify-center font-bold">
                    {orderEnquiries.filter((o) => o.status === 'New').length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('menu')}
                className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'menu'
                    ? 'border-[#C9A45C] text-[#C9A45C] font-semibold'
                    : 'border-transparent text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
                }`}
              >
                <UtensilsCrossed className="w-4 h-4" />
                <span>Menu Management ({menuItems.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('info')}
                className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'info'
                    ? 'border-[#C9A45C] text-[#C9A45C] font-semibold'
                    : 'border-transparent text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>Restaurant Details</span>
              </button>

              <button
                onClick={() => setActiveTab('gallery')}
                className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'gallery'
                    ? 'border-[#C9A45C] text-[#C9A45C] font-semibold'
                    : 'border-transparent text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
                }`}
              >
                <ImageIcon className="w-4 h-4" />
                <span>Gallery Images</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-2 py-3 px-4 text-xs sm:text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'settings'
                    ? 'border-[#C9A45C] text-[#C9A45C] font-semibold'
                    : 'border-transparent text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
                }`}
              >
                <Key className="w-4 h-4" />
                <span>Security & Reset</span>
              </button>
            </div>

            {/* Tab Body */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-8 text-left">
              {/* TAB 1: ORDER ENQUIRIES */}
              {activeTab === 'orders' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-serif text-xl font-semibold text-[#F8F4EC]">
                        Submitted Customer Enquiries
                      </h4>
                      <p className="text-xs text-[#F8F4EC]/65">
                        Real enquiries submitted via the website ordering flow.
                      </p>
                    </div>
                  </div>

                  {orderEnquiries.length === 0 ? (
                    <div className="py-16 text-center bg-[#191919] border border-[#2B2B2B] rounded-2xl p-8 space-y-2">
                      <ShoppingBag className="w-10 h-10 text-[#C9A45C]/50 mx-auto" />
                      <h5 className="font-serif text-lg text-[#F8F4EC]">
                        No order enquiries submitted yet
                      </h5>
                      <p className="text-xs text-[#F8F4EC]/60 max-w-sm mx-auto">
                        When visitors build an enquiry on the website, their selected dishes, phone number, and preference will appear here.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orderEnquiries.map((enq) => {
                        const cleanPhone = enq.customerPhone.replace(/\D/g, '');
                        const waCustomerUrl = `https://wa.me/91${cleanPhone}?text=${encodeURIComponent(
                          `Hello ${enq.customerName}, this is Golden Bowl confirming your order enquiry (${enq.id}).`
                        )}`;

                        return (
                          <div
                            key={enq.id}
                            className="p-5 rounded-2xl bg-[#191919] border border-[#2E2E2E] space-y-4"
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#252525] pb-3">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-serif text-lg font-semibold text-[#F8F4EC]">
                                    {enq.customerName}
                                  </span>
                                  <span className="text-xs font-mono text-[#C9A45C]">
                                    {enq.id}
                                  </span>
                                </div>
                                <p className="text-xs text-[#F8F4EC]/60 mt-0.5">
                                  Submitted on {new Date(enq.createdAt).toLocaleString()} · {enq.preference}
                                </p>
                              </div>

                              {/* Status Select */}
                              <div className="flex items-center gap-3">
                                <span className="text-xs text-[#F8F4EC]/60">Status:</span>
                                <select
                                  value={enq.status}
                                  onChange={(e) =>
                                    updateEnquiryStatus(
                                      enq.id,
                                      e.target.value as OrderEnquiry['status']
                                    )
                                  }
                                  className="text-xs bg-[#242424] text-[#F8F4EC] border border-[#3A3A3A] rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#C9A45C]"
                                >
                                  <option value="New">New Enquiry</option>
                                  <option value="Contacted">Contacted Customer</option>
                                  <option value="Confirmed">Confirmed / Preparing</option>
                                  <option value="Completed">Completed</option>
                                  <option value="Cancelled">Cancelled</option>
                                </select>

                                <button
                                  onClick={() => deleteOrderEnquiry(enq.id)}
                                  className="text-[#F8F4EC]/40 hover:text-red-400 p-1 transition-colors"
                                  title="Delete record"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            {/* Enquired Items */}
                            <div className="space-y-1.5">
                              <span className="text-[11px] font-semibold text-[#C9A45C] uppercase tracking-wider block">
                                Requested Items:
                              </span>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                                {enq.items.map((item, idx) => (
                                  <div
                                    key={idx}
                                    className="p-2 rounded-lg bg-[#202020] border border-[#2B2B2B] flex justify-between"
                                  >
                                    <span className="text-[#F8F4EC] font-medium">
                                      {item.name} × {item.quantity}
                                    </span>
                                    <span className="text-[#F8F4EC]/60">
                                      {item.price ? `₹${item.price * item.quantity}` : 'Price TBD'}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {enq.notes && (
                              <p className="text-xs text-[#F8F4EC]/75 bg-[#202020] p-2.5 rounded-lg border border-[#2A2A2A]">
                                <span className="text-[#C9A45C] font-medium">Customer Note: </span>
                                {enq.notes}
                              </p>
                            )}

                            {/* Direct Contact Actions */}
                            <div className="flex flex-wrap items-center gap-3 pt-2">
                              <a
                                href={`tel:${cleanPhone}`}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-colors"
                              >
                                <Phone className="w-3.5 h-3.5" />
                                <span>Call Customer ({enq.customerPhone})</span>
                              </a>

                              <a
                                href={waCustomerUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-[#25D366] hover:bg-[#20bd5a] rounded-lg transition-colors"
                              >
                                <MessageCircle className="w-3.5 h-3.5 text-black" />
                                <span className="text-black font-semibold">WhatsApp Customer</span>
                              </a>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: MENU MANAGEMENT */}
              {activeTab === 'menu' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h4 className="font-serif text-xl font-semibold text-[#F8F4EC]">
                        Restaurant Menu Items ({menuItems.length})
                      </h4>
                      <p className="text-xs text-[#F8F4EC]/65">
                        Add dishes, set prices, edit descriptions, and toggle availability.
                      </p>
                    </div>

                    {!isAddingItem && !editingItem && (
                      <button
                        onClick={startAddItem}
                        className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-xl transition-all cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add New Dish</span>
                      </button>
                    )}
                  </div>

                  {/* Add or Edit Dish Form */}
                  {(isAddingItem || editingItem) && (
                    <form
                      onSubmit={handleCreateOrUpdateItem}
                      className="p-6 rounded-2xl bg-[#1C1C1C] border border-[#333333] space-y-4"
                    >
                      <h5 className="font-serif text-lg font-semibold text-[#C9A45C]">
                        {editingItem ? `Edit Dish: ${editingItem.name}` : 'Add New Menu Item'}
                      </h5>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-medium text-[#F8F4EC]/80">Dish Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Schezwan Fried Rice"
                            value={itemName}
                            onChange={(e) => setItemName(e.target.value)}
                            className="w-full px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-medium text-[#F8F4EC]/80">Category</label>
                          <select
                            value={itemCategory}
                            onChange={(e) => setItemCategory(e.target.value as MenuCategory)}
                            className="w-full px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                          >
                            <option value="Chinese Starters">Chinese Starters</option>
                            <option value="Noodles">Noodles</option>
                            <option value="Fried Rice">Fried Rice</option>
                            <option value="Chicken Specials">Chicken Specials</option>
                            <option value="Paneer Specials">Paneer Specials</option>
                            <option value="Main Course">Main Course</option>
                            <option value="Breads">Breads</option>
                            <option value="Soups">Soups</option>
                            <option value="Beverages">Beverages</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-medium text-[#F8F4EC]/80">
                            Price (₹) <span className="text-[#F8F4EC]/40 font-normal">(Leave blank for "Contact us for price")</span>
                          </label>
                          <input
                            type="number"
                            placeholder="e.g. 180 (or empty)"
                            value={itemPrice}
                            onChange={(e) => setItemPrice(e.target.value)}
                            className="w-full px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-medium text-[#F8F4EC]/80">Dietary Classification</label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setItemVeg(true)}
                              className={`py-2 px-3 text-xs rounded-lg border font-medium cursor-pointer ${
                                itemVeg === true
                                  ? 'bg-[#107C41] text-white border-[#107C41]'
                                  : 'bg-[#252525] text-[#F8F4EC]/70 border-[#3A3A3A]'
                              }`}
                            >
                              Vegetarian
                            </button>
                            <button
                              type="button"
                              onClick={() => setItemVeg(false)}
                              className={`py-2 px-3 text-xs rounded-lg border font-medium cursor-pointer ${
                                itemVeg === false
                                  ? 'bg-[#A4262C] text-white border-[#A4262C]'
                                  : 'bg-[#252525] text-[#F8F4EC]/70 border-[#3A3A3A]'
                              }`}
                            >
                              Non-Vegetarian
                            </button>
                          </div>
                        </div>

                        <div className="sm:col-span-2 space-y-1">
                          <label className="text-xs font-medium text-[#F8F4EC]/80">Description</label>
                          <textarea
                            rows={2}
                            placeholder="Brief verified dish description..."
                            value={itemDesc}
                            onChange={(e) => setItemDesc(e.target.value)}
                            className="w-full px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none resize-none"
                          />
                        </div>

                        <div className="sm:col-span-2 flex items-center gap-3">
                          <input
                            type="checkbox"
                            id="popularCheck"
                            checked={itemPopular}
                            onChange={(e) => setItemPopular(e.target.checked)}
                            className="w-4 h-4 accent-[#C9A45C]"
                          />
                          <label htmlFor="popularCheck" className="text-xs text-[#F8F4EC]">
                            Highlight as "Popular Favorite" on the menu
                          </label>
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#333333]">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingItem(null);
                            setIsAddingItem(false);
                          }}
                          className="px-4 py-2 text-xs font-medium text-[#F8F4EC]/70 hover:text-[#F8F4EC]"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 text-xs font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-colors cursor-pointer"
                        >
                          {editingItem ? 'Save Changes' : 'Add Dish'}
                        </button>
                      </div>
                    </form>
                  )}

                  {/* List of existing dishes */}
                  <div className="divide-y divide-[#242424] border border-[#2B2B2B] rounded-2xl overflow-hidden bg-[#181818]">
                    {menuItems.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-[#1E1E1E] transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-12 h-12 rounded-lg object-cover bg-[#222222] shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <h5 className="text-sm font-semibold text-[#F8F4EC] truncate">
                                {item.name}
                              </h5>
                              {item.isVeg === true && (
                                <span className="text-[10px] text-[#107C41] font-semibold border border-[#107C41] px-1 rounded">
                                  VEG
                                </span>
                              )}
                              {item.isVeg === false && (
                                <span className="text-[10px] text-[#A4262C] font-semibold border border-[#A4262C] px-1 rounded">
                                  NON-VEG
                                </span>
                              )}
                              {item.isPopular && (
                                <span className="text-[10px] text-[#C9A45C]">★ Popular</span>
                              )}
                            </div>
                            <p className="text-xs text-[#F8F4EC]/60 truncate">
                              {item.category} · {item.price ? `₹${item.price}` : 'Contact us for price'}
                            </p>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                          <button
                            onClick={() => toggleItemAvailability(item.id)}
                            className={`px-2.5 py-1 text-xs rounded-lg border font-medium flex items-center gap-1 transition-colors cursor-pointer ${
                              item.isAvailable
                                ? 'bg-[#107C41]/20 border-[#107C41] text-[#107C41]'
                                : 'bg-[#641E24]/20 border-[#641E24] text-red-300'
                            }`}
                          >
                            {item.isAvailable ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                            <span>{item.isAvailable ? 'Available' : 'Unavailable'}</span>
                          </button>

                          <button
                            onClick={() => startEditItem(item)}
                            className="p-1.5 text-[#F8F4EC]/60 hover:text-[#C9A45C] hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                            title="Edit dish"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              if (confirm(`Remove "${item.name}" from menu?`)) {
                                deleteMenuItem(item.id);
                              }
                            }}
                            className="p-1.5 text-[#F8F4EC]/60 hover:text-red-400 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                            title="Delete dish"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: RESTAURANT INFO */}
              {activeTab === 'info' && (
                <form onSubmit={handleSaveInfo} className="space-y-6">
                  <div>
                    <h4 className="font-serif text-xl font-semibold text-[#F8F4EC]">
                      Restaurant Details & Content
                    </h4>
                    <p className="text-xs text-[#F8F4EC]/65">
                      Update address, phone, opening hours status, and story text.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Phone Number</label>
                      <input
                        type="text"
                        value={infoForm.phone}
                        onChange={(e) => setInfoForm({ ...infoForm, phone: e.target.value })}
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Reported Price Range</label>
                      <input
                        type="text"
                        value={infoForm.priceRange}
                        onChange={(e) => setInfoForm({ ...infoForm, priceRange: e.target.value })}
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Address</label>
                      <input
                        type="text"
                        value={infoForm.address}
                        onChange={(e) => setInfoForm({ ...infoForm, address: e.target.value })}
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Opening Hours Status</label>
                      <input
                        type="text"
                        value={infoForm.openingHoursStatus}
                        onChange={(e) => setInfoForm({ ...infoForm, openingHoursStatus: e.target.value })}
                        placeholder="e.g. Open daily 11:30 AM – 10:30 PM"
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Opening Hours Note</label>
                      <input
                        type="text"
                        value={infoForm.openingHoursNote}
                        onChange={(e) => setInfoForm({ ...infoForm, openingHoursNote: e.target.value })}
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Story Headline</label>
                      <input
                        type="text"
                        value={infoForm.storyHeadline}
                        onChange={(e) => setInfoForm({ ...infoForm, storyHeadline: e.target.value })}
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Story Paragraph 1</label>
                      <textarea
                        rows={2}
                        value={infoForm.storyParagraph1}
                        onChange={(e) => setInfoForm({ ...infoForm, storyParagraph1: e.target.value })}
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none resize-none"
                      />
                    </div>

                    <div className="sm:col-span-2 space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">Story Paragraph 2</label>
                      <textarea
                        rows={2}
                        value={infoForm.storyParagraph2}
                        onChange={(e) => setInfoForm({ ...infoForm, storyParagraph2: e.target.value })}
                        className="w-full px-3 py-2 bg-[#1C1C1C] border border-[#333333] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none resize-none"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="px-6 py-2.5 text-xs font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-xl transition-colors cursor-pointer"
                    >
                      Save Restaurant Details
                    </button>
                  </div>
                </form>
              )}

              {/* TAB 4: GALLERY */}
              {activeTab === 'gallery' && (
                <div className="space-y-6">
                  <div>
                    <h4 className="font-serif text-xl font-semibold text-[#F8F4EC]">
                      Gallery Images ({galleryImages.length})
                    </h4>
                    <p className="text-xs text-[#F8F4EC]/65">
                      Manage visual images showcased on the website.
                    </p>
                  </div>

                  {/* Add Image Form */}
                  <form
                    onSubmit={handleAddGalleryImage}
                    className="p-5 rounded-2xl bg-[#1C1C1C] border border-[#333333] space-y-3"
                  >
                    <h5 className="text-xs uppercase font-semibold text-[#C9A45C] tracking-wider">
                      Add New Photo to Gallery
                    </h5>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        required
                        placeholder="Image Title (e.g., Crispy Spring Rolls)"
                        value={newImageTitle}
                        onChange={(e) => setNewImageTitle(e.target.value)}
                        className="px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-xs text-[#F8F4EC]"
                      />
                      <input
                        type="text"
                        required
                        placeholder="Image URL or Asset Path"
                        value={newImageUrl}
                        onChange={(e) => setNewImageUrl(e.target.value)}
                        className="px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-xs text-[#F8F4EC]"
                      />
                      <input
                        type="text"
                        placeholder="Caption description"
                        value={newImageCaption}
                        onChange={(e) => setNewImageCaption(e.target.value)}
                        className="sm:col-span-2 px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-xs text-[#F8F4EC]"
                      />
                    </div>
                    <div className="flex justify-end pt-1">
                      <button
                        type="submit"
                        className="px-4 py-2 text-xs font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-colors cursor-pointer"
                      >
                        Add to Gallery
                      </button>
                    </div>
                  </form>

                  {/* Existing gallery cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {galleryImages.map((img) => (
                      <div
                        key={img.id}
                        className="p-3 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A] space-y-2 relative group"
                      >
                        <img
                          src={img.imageUrl}
                          alt={img.title}
                          className="w-full h-36 object-cover rounded-lg bg-[#222222]"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex items-center justify-between">
                          <div>
                            <h6 className="text-xs font-semibold text-[#F8F4EC] truncate max-w-[180px]">
                              {img.title}
                            </h6>
                            <span className="text-[10px] text-[#C9A45C]">{img.category}</span>
                          </div>
                          <button
                            onClick={() => deleteGalleryImage(img.id)}
                            className="text-[#F8F4EC]/40 hover:text-red-400 p-1"
                            title="Remove image"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: SECURITY & RESET */}
              {activeTab === 'settings' && (
                <div className="max-w-lg space-y-8">
                  {/* Change PIN Form */}
                  <form onSubmit={handlePinChange} className="p-6 rounded-2xl bg-[#1C1C1C] border border-[#333333] space-y-4">
                    <h5 className="font-serif text-lg font-semibold text-[#F8F4EC]">
                      Change Owner PIN
                    </h5>
                    <p className="text-xs text-[#F8F4EC]/65">
                      Update the PIN used to log into this owner dashboard.
                    </p>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-[#F8F4EC]/80">New PIN (at least 4 digits)</label>
                      <input
                        type="password"
                        required
                        minLength={4}
                        placeholder="e.g. 5678"
                        value={newPin}
                        onChange={(e) => setNewPin(e.target.value)}
                        className="w-full px-3 py-2 bg-[#252525] border border-[#3A3A3A] rounded-lg text-sm text-[#F8F4EC] focus:border-[#C9A45C] focus:outline-none"
                      />
                    </div>

                    {pinSuccess && (
                      <p className="text-xs text-emerald-400 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>Owner PIN successfully updated.</span>
                      </p>
                    )}

                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-semibold text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-colors cursor-pointer"
                    >
                      Update PIN
                    </button>
                  </form>

                  {/* Reset to Defaults */}
                  <div className="p-6 rounded-2xl bg-[#1C1C1C] border border-[#641E24]/60 space-y-3">
                    <h5 className="font-serif text-lg font-semibold text-red-200">
                      Reset Data to Defaults
                    </h5>
                    <p className="text-xs text-[#F8F4EC]/65 leading-relaxed">
                      Restore initial menu dishes, original gallery images, and default restaurant details.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm('Are you sure you want to restore default restaurant and menu data?')) {
                          resetToDefaults();
                          alert('Restored default Golden Bowl content.');
                        }
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-red-200 bg-[#641E24]/30 hover:bg-[#641E24] border border-[#641E24] rounded-lg transition-colors cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Reset to Initial Defaults</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
