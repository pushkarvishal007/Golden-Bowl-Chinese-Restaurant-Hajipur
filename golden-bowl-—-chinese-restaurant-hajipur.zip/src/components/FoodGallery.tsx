import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  X,
} from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useRestaurant } from '../context/RestaurantContext';
import { GalleryImage } from '../types/restaurant';

export const FoodGallery: React.FC = () => {
  const { galleryImages } = useRestaurant();
  const [activeImageIndex, setActiveImageIndex] = useState<number | null>(null);

  // Keyboard navigation for Lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeImageIndex === null) return;
      if (e.key === 'Escape') {
        setActiveImageIndex(null);
      } else if (e.key === 'ArrowRight') {
        setActiveImageIndex((prev) =>
          prev !== null ? (prev + 1) % galleryImages.length : 0
        );
      } else if (e.key === 'ArrowLeft') {
        setActiveImageIndex((prev) =>
          prev !== null ? (prev - 1 + galleryImages.length) % galleryImages.length : 0
        );
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeImageIndex, galleryImages.length]);

  return (
    <section id="gallery" className="py-20 lg:py-28 bg-[#151515] border-t border-b border-[#242424]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C9A45C]">
            <span>Visual Showcase</span>
            <span aria-hidden="true">·</span>
            <span>Culinary Moments</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-[#F8F4EC] tracking-tight [text-wrap:balance]">
            Food & Ambience Gallery
          </h2>

          <p className="text-base text-[#F8F4EC]/75 leading-relaxed font-normal">
            Take a visual tour of our wok kitchen craft, sizzling appetizers, rich noodle bowls, and welcoming dining room.
          </p>
        </div>

        {/* Editorial Masonry Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <div
              key={image.id}
              onClick={() => setActiveImageIndex(index)}
              className="relative group rounded-2xl overflow-hidden border border-[#2B2B2B] bg-[#1C1C1C] cursor-pointer aspect-[4/3] sm:aspect-auto sm:h-72"
            >
              <img
                src={image.imageUrl}
                alt={image.title}
                className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 ease-out"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              <div className="absolute inset-0 p-5 flex flex-col justify-between text-left">
                <div className="flex justify-end">
                  <span className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-[#F8F4EC] opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-4 h-4 text-[#C9A45C]" />
                  </span>
                </div>

                <div className="space-y-1 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                  <span className="text-[11px] font-semibold text-[#C9A45C] uppercase tracking-wider block">
                    {image.category}
                  </span>
                  <h3 className="font-serif text-lg font-semibold text-[#F8F4EC]">
                    {image.title}
                  </h3>
                  <p className="text-xs text-[#F8F4EC]/70 line-clamp-1">
                    {image.caption}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeImageIndex !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          {/* Close button */}
          <button
            onClick={() => setActiveImageIndex(null)}
            className="absolute top-5 right-5 p-2 rounded-full bg-[#1F1F1F] text-[#F8F4EC] hover:text-[#C9A45C] hover:bg-[#2A2A2A] transition-colors z-50 cursor-pointer"
            aria-label="Close lightbox"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Previous button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setActiveImageIndex((prev) =>
                prev !== null ? (prev - 1 + galleryImages.length) % galleryImages.length : 0
              );
            }}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#1F1F1F]/80 text-[#F8F4EC] hover:text-[#C9A45C] hover:bg-[#2A2A2A] transition-colors z-50 cursor-pointer"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setActiveImageIndex((prev) =>
                prev !== null ? (prev + 1) % galleryImages.length : 0
              );
            }}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#1F1F1F]/80 text-[#F8F4EC] hover:text-[#C9A45C] hover:bg-[#2A2A2A] transition-colors z-50 cursor-pointer"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Modal Container */}
          <div
            className="max-w-4xl w-full max-h-[85vh] flex flex-col rounded-2xl overflow-hidden bg-[#181818] border border-[#333333] shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative flex-1 max-h-[65vh] bg-black flex items-center justify-center overflow-hidden">
              <img
                src={galleryImages[activeImageIndex].imageUrl}
                alt={galleryImages[activeImageIndex].title}
                className="max-h-[65vh] w-auto max-w-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-6 bg-[#181818] border-t border-[#2A2A2A] flex items-center justify-between text-left">
              <div>
                <span className="text-xs uppercase font-semibold text-[#C9A45C] tracking-wider block mb-1">
                  {galleryImages[activeImageIndex].category}
                </span>
                <h4 className="font-serif text-xl font-semibold text-[#F8F4EC]">
                  {galleryImages[activeImageIndex].title}
                </h4>
                <p className="text-xs sm:text-sm text-[#F8F4EC]/70 mt-1">
                  {galleryImages[activeImageIndex].caption}
                </p>
              </div>
              <span className="text-xs font-mono text-[#F8F4EC]/40 tabular-nums">
                {activeImageIndex + 1} / {galleryImages.length}
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
