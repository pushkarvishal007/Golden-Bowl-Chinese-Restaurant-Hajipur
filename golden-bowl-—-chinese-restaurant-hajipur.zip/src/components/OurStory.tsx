import { Flame, HeartHandshake, Sparkles } from 'lucide-react';
import React from 'react';
import { useRestaurant } from '../context/RestaurantContext';

export const OurStory: React.FC = () => {
  const { restaurantInfo } = useRestaurant();

  return (
    <section id="story" className="py-20 lg:py-28 bg-[#151515] border-t border-b border-[#222222]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Visual Showcase (Atmospheric dining room photograph) */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#2D2D2D] shadow-2xl group">
              <img
                src="/src/assets/images/restaurant_interior_warm_1791946786520.jpg"
                alt="Golden Bowl dining room and ambient seating"
                className="w-full h-[380px] sm:h-[460px] object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-xs uppercase tracking-widest text-[#C9A45C] font-semibold block mb-1">
                  Dining Experience
                </span>
                <p className="text-sm font-medium text-[#F8F4EC]/90">
                  A comfortable, welcoming environment for family meals and friendly gatherings in Hajipur.
                </p>
              </div>
            </div>

            {/* Subtle decorative geometric border offset */}
            <div className="hidden sm:block absolute -top-3 -left-3 w-20 h-20 border-t-2 border-l-2 border-[#C9A45C]/30 rounded-tl-2xl pointer-events-none" />
            <div className="hidden sm:block absolute -bottom-3 -right-3 w-20 h-20 border-b-2 border-r-2 border-[#C9A45C]/30 rounded-br-2xl pointer-events-none" />
          </div>

          {/* Narrative Content */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C9A45C]">
              <span>About Golden Bowl</span>
              <span aria-hidden="true">/</span>
              <span>Our Philosophy</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-[#F8F4EC] tracking-tight [text-wrap:balance]">
              {restaurantInfo.storyHeadline}
            </h2>

            <div className="space-y-4 text-base sm:text-lg text-[#F8F4EC]/80 leading-relaxed font-normal">
              <p>{restaurantInfo.storyParagraph1}</p>
              <p>{restaurantInfo.storyParagraph2}</p>
            </div>

            {/* Three key pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-[#252525]">
              <div className="space-y-2">
                <div className="w-9 h-9 rounded-lg bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C]">
                  <Flame className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-semibold text-[#F8F4EC]">Wok Mastery</h4>
                <p className="text-xs text-[#F8F4EC]/65 leading-relaxed">
                  High-heat wok cooking for crisp textures and balanced seasonings.
                </p>
              </div>

              <div className="space-y-2">
                <div className="w-9 h-9 rounded-lg bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C]">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-semibold text-[#F8F4EC]">Flavorful Choices</h4>
                <p className="text-xs text-[#F8F4EC]/65 leading-relaxed">
                  Carefully prepared Chinese appetizers, noodles, rice, and regional favorites.
                </p>
              </div>

              <div className="space-y-2">
                <div className="w-9 h-9 rounded-lg bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C]">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-semibold text-[#F8F4EC]">Warm Service</h4>
                <p className="text-xs text-[#F8F4EC]/65 leading-relaxed">
                  Friendly and considerate attention for every guest and family table.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
