import {
  Check,
  EyeOff,
  Filter,
  Phone,
  Plus,
  Search,
  ShoppingBag,
} from 'lucide-react';
import React, { useMemo, useState } from 'react';
import { useRestaurant } from '../context/RestaurantContext';
import { MenuCategory, MenuItem } from '../types/restaurant';

export const MenuSection: React.FC = () => {
  const { menuItems, addToCart, cart, restaurantInfo } = useRestaurant();
  const [selectedCategory, setSelectedCategory] = useState<MenuCategory | 'All'>('All');
  const [dietaryFilter, setDietaryFilter] = useState<'All' | 'Veg' | 'Non-Veg'>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const categories: (MenuCategory | 'All')[] = [
    'All',
    'Popular Favorites',
    'Chinese Starters',
    'Noodles',
    'Fried Rice',
    'Chicken Specials',
    'Paneer Specials',
    'Main Course',
    'Breads',
    'Soups',
    'Beverages',
  ];

  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      // Category filter
      if (selectedCategory === 'Popular Favorites') {
        if (!item.isPopular) return false;
      } else if (selectedCategory !== 'All' && item.category !== selectedCategory) {
        return false;
      }

      // Dietary filter
      if (dietaryFilter === 'Veg' && item.isVeg !== true) return false;
      if (dietaryFilter === 'Non-Veg' && item.isVeg !== false) return false;

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDesc = item.description?.toLowerCase().includes(query);
        const matchesCat = item.category.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc && !matchesCat) return false;
      }

      return true;
    });
  }, [menuItems, selectedCategory, dietaryFilter, searchQuery]);

  return (
    <section id="menu" className="py-20 lg:py-28 bg-[#121212]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C9A45C]">
            <span>Signature Offerings</span>
            <span aria-hidden="true">·</span>
            <span>Wok & Kitchen</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-[#F8F4EC] tracking-tight [text-wrap:balance]">
            Our Restaurant Menu
          </h2>

          <p className="text-base text-[#F8F4EC]/75 leading-relaxed font-normal">
            Explore authentic Chinese appetizers, wok-tossed noodles, aromatic rice, and savory curries.
            Select your favorites to create an order enquiry or call us directly.
          </p>

          <p className="text-xs text-[#C9A45C]/90 italic">
            *Pricing policy: Unconfigured item prices display "Contact us for price" until set by the restaurant owner.
          </p>
        </div>

        {/* Search & Dietary Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8">
          {/* Search Bar */}
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#F8F4EC]/40" />
            <input
              type="text"
              placeholder="Search dishes (e.g., Lollipop, Noodles)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-[#1B1B1B] border border-[#2E2E2E] rounded-lg text-sm text-[#F8F4EC] placeholder-[#F8F4EC]/40 focus:outline-none focus:border-[#C9A45C] transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#F8F4EC]/50 hover:text-[#F8F4EC]"
              >
                Clear
              </button>
            )}
          </div>

          {/* Dietary Filter Segmented Control */}
          <div className="flex items-center gap-1 p-1 bg-[#1A1A1A] border border-[#2B2B2B] rounded-lg self-stretch sm:self-auto justify-center">
            <button
              onClick={() => setDietaryFilter('All')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                dietaryFilter === 'All'
                  ? 'bg-[#C9A45C] text-[#121212] font-semibold'
                  : 'text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
              }`}
            >
              All Types
            </button>
            <button
              onClick={() => setDietaryFilter('Veg')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                dietaryFilter === 'Veg'
                  ? 'bg-[#107C41] text-white font-semibold'
                  : 'text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-[#107C41] border border-white/60" />
              <span>Veg Only</span>
            </button>
            <button
              onClick={() => setDietaryFilter('Non-Veg')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                dietaryFilter === 'Non-Veg'
                  ? 'bg-[#A4262C] text-white font-semibold'
                  : 'text-[#F8F4EC]/70 hover:text-[#F8F4EC]'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-[#A4262C] border border-white/60" />
              <span>Non-Veg Only</span>
            </button>
          </div>
        </div>

        {/* Category Horizontal Filter Bar */}
        <div className="overflow-x-auto pb-4 mb-8 -mx-4 px-4 sm:mx-0 sm:px-0">
          <div className="flex items-center gap-2 min-w-max">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#C9A45C] text-[#121212] font-semibold shadow-md shadow-[#C9A45C]/15'
                    : 'bg-[#1B1B1B] text-[#F8F4EC]/75 hover:text-[#F8F4EC] hover:bg-[#252525] border border-[#2E2E2E]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-[#161616] border border-[#272727] rounded-2xl p-8 space-y-3">
            <Filter className="w-8 h-8 text-[#C9A45C]/60 mx-auto" />
            <h3 className="font-serif text-lg text-[#F8F4EC]">No matching dishes found</h3>
            <p className="text-sm text-[#F8F4EC]/60 max-w-sm mx-auto">
              Try adjusting your search query, selecting another category, or clearing the dietary filters.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setDietaryFilter('All');
                setSearchQuery('');
              }}
              className="mt-2 text-xs font-medium text-[#C9A45C] hover:underline"
            >
              Reset all filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredItems.map((item) => (
              <MenuCard key={item.id} item={item} />
            ))}
          </div>
        )}

        {/* Bottom Ordering Note */}
        <div className="mt-14 p-6 rounded-2xl bg-[#161616] border border-[#2B2B2B] flex flex-col sm:flex-row items-center justify-between gap-6 text-left">
          <div className="space-y-1">
            <h4 className="font-serif text-lg font-semibold text-[#F8F4EC]">
              Looking to customize or confirm daily specials?
            </h4>
            <p className="text-xs sm:text-sm text-[#F8F4EC]/70">
              Speak directly with our team at Golden Bowl for custom spice levels, availability, and party orders.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <a
              href={`tel:${restaurantInfo.phoneRaw}`}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-medium text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-lg transition-colors whitespace-nowrap"
            >
              <Phone className="w-4 h-4" />
              <span>Call: {restaurantInfo.phone}</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

interface MenuCardProps {
  item: MenuItem;
}

const MenuCard: React.FC<MenuCardProps> = ({ item }) => {
  const { addToCart, cart, restaurantInfo } = useRestaurant();
  const quantityInCart = cart[item.id] || 0;

  return (
    <div className="bg-[#181818] border border-[#2B2B2B] hover:border-[#C9A45C]/50 rounded-2xl overflow-hidden flex flex-col transition-all duration-300 hover:-translate-y-1 hover:shadow-xl group">
      {/* Food Photography Slot */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#202020]">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-transparent to-transparent opacity-80" />

        {/* FSSAI Standard Veg / Non-Veg Indicator */}
        <div className="absolute top-3 left-3 bg-[#121212]/80 backdrop-blur-md p-1.5 rounded-md border border-[#333333]">
          {item.isVeg === true && (
            <div
              className="w-4 h-4 border-2 border-[#107C41] flex items-center justify-center rounded-xs"
              title="Vegetarian"
            >
              <span className="w-2 h-2 rounded-full bg-[#107C41]" />
            </div>
          )}
          {item.isVeg === false && (
            <div
              className="w-4 h-4 border-2 border-[#A4262C] flex items-center justify-center rounded-xs"
              title="Non-Vegetarian"
            >
              <span className="w-2 h-2 bg-[#A4262C] rotate-45 transform" />
            </div>
          )}
          {item.isVeg === null && (
            <span className="text-[10px] text-[#F8F4EC]/60 px-1 font-sans">Kitchen</span>
          )}
        </div>

        {/* Availability Badge */}
        {!item.isAvailable && (
          <div className="absolute top-3 right-3 bg-[#641E24]/90 text-white text-[11px] font-semibold px-2 py-1 rounded backdrop-blur-sm flex items-center gap-1">
            <EyeOff className="w-3 h-3" />
            <span>Currently Unavailable</span>
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4 text-left">
        <div className="space-y-2">
          {/* Category kicker */}
          <div className="flex items-center justify-between text-xs text-[#C9A45C] font-medium tracking-wide">
            <span>{item.category}</span>
            {item.isPopular && <span className="text-[11px] text-[#E0C489]">★ Popular</span>}
          </div>

          {/* Dish Name */}
          <h3 className="font-serif text-xl font-semibold text-[#F8F4EC] tracking-tight group-hover:text-[#C9A45C] transition-colors">
            {item.name}
          </h3>

          {/* Verified Description */}
          {item.description && (
            <p className="text-xs sm:text-sm text-[#F8F4EC]/70 line-clamp-2 leading-relaxed">
              {item.description}
            </p>
          )}
        </div>

        {/* Price & Action Row */}
        <div className="pt-3 border-t border-[#262626] flex items-center justify-between gap-3">
          {/* Price display (Contact us for price if unconfigured) */}
          <div className="space-y-0.5">
            <span className="text-[10px] uppercase tracking-wider text-[#F8F4EC]/50 block">
              Price
            </span>
            {item.price !== null && item.price !== undefined ? (
              <span className="font-semibold text-lg text-[#F8F4EC] tabular-nums">
                ₹{item.price}
              </span>
            ) : (
              <span className="text-xs font-medium text-[#C9A45C] block">
                Contact us for price
              </span>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <a
              href={`tel:${restaurantInfo.phoneRaw}`}
              aria-label={`Call to enquire about ${item.name}`}
              className="p-2.5 rounded-lg border border-[#333333] text-[#F8F4EC]/70 hover:text-[#C9A45C] hover:border-[#C9A45C]/50 transition-colors"
              title="Call to Order"
            >
              <Phone className="w-4 h-4" />
            </a>

            <button
              onClick={() => addToCart(item)}
              disabled={!item.isAvailable}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                !item.isAvailable
                  ? 'bg-[#252525] text-[#F8F4EC]/30 cursor-not-allowed'
                  : quantityInCart > 0
                  ? 'bg-[#C9A45C] text-[#121212] font-semibold'
                  : 'bg-[#222222] hover:bg-[#C9A45C] text-[#F8F4EC] hover:text-[#121212] border border-[#3A3A3A] hover:border-[#C9A45C]'
              }`}
            >
              {quantityInCart > 0 ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Enquired ({quantityInCart})</span>
                </>
              ) : (
                <>
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add to Enquiry</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
