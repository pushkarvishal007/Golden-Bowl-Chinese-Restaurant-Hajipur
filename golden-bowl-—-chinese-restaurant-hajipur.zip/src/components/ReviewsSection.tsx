import {
  ExternalLink,
  MessageSquarePlus,
  ShieldCheck,
  Star,
  Users,
  Utensils,
  Wallet,
} from 'lucide-react';
import React from 'react';
import { useRestaurant } from '../context/RestaurantContext';

export const ReviewsSection: React.FC = () => {
  const { restaurantInfo } = useRestaurant();

  const writeReviewUrl = `https://www.google.com/maps/search/?api=1&query=Golden+Bowl+Kachahari+Road+Ramsagar+Singh+Complex+Hajipur+Bihar+844101`;

  return (
    <section id="reviews" className="py-20 lg:py-28 bg-[#121212]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C9A45C]">
            <span>Guest Feedback & Reputation</span>
            <span aria-hidden="true">·</span>
            <span>Local Community</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-semibold text-[#F8F4EC] tracking-tight [text-wrap:balance]">
            Trusted by Diners in Hajipur
          </h2>

          <p className="text-base text-[#F8F4EC]/75 leading-relaxed font-normal">
            We value genuine hospitality and authentic feedback. Below is the reference rating supplied from the restaurant's business profile.
          </p>
        </div>

        {/* Highlight Scorecard with Verified Transparency Note */}
        <div className="bg-[#181818] border border-[#2D2D2D] rounded-3xl p-8 sm:p-10 mb-12 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Rating Number Column */}
            <div className="lg:col-span-5 text-center lg:text-left space-y-3 lg:border-r border-[#2C2C2C] lg:pr-8">
              <span className="text-xs uppercase tracking-widest text-[#C9A45C] font-semibold block">
                Google Business Listing Reference
              </span>

              <div className="flex items-center justify-center lg:justify-start gap-4">
                <span className="text-5xl sm:text-6xl font-serif font-bold text-[#F8F4EC] tabular-nums">
                  {restaurantInfo.ratingReference}
                </span>
                <div className="space-y-1 text-left">
                  <div className="flex items-center gap-1 text-[#C9A45C]">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-[#C9A45C] text-[#C9A45C]" />
                    ))}
                  </div>
                  <span className="text-xs text-[#F8F4EC]/70 block tabular-nums">
                    Based on {restaurantInfo.reviewCountReference} Google reviews
                  </span>
                </div>
              </div>

              {/* Exact Transparency Label */}
              <div className="pt-2">
                <p className="text-xs text-[#F8F4EC]/55 leading-relaxed">
                  *{restaurantInfo.ratingNote}
                </p>
              </div>
            </div>

            {/* Real Link Action Column */}
            <div className="lg:col-span-7 flex flex-col sm:flex-row items-center justify-center lg:justify-end gap-4">
              <a
                href={restaurantInfo.mapsSearchUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold tracking-wide text-[#121212] bg-[#C9A45C] hover:bg-[#E0C489] rounded-xl transition-all shadow-md active:scale-[0.98]"
              >
                <span>Read Google Reviews</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              <a
                href={writeReviewUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold tracking-wide text-[#F8F4EC] bg-[#222222] hover:bg-[#2A2A2A] border border-[#3A3A3A] hover:border-[#C9A45C]/50 rounded-xl transition-all active:scale-[0.98]"
              >
                <MessageSquarePlus className="w-4 h-4 text-[#C9A45C]" />
                <span>Write a Review</span>
              </a>
            </div>
          </div>
        </div>

        {/* What Diners Appreciate (Grounded thematic pillars without fake quotes) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          <div className="p-6 rounded-2xl bg-[#161616] border border-[#282828] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C]">
              <Utensils className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-semibold text-[#F8F4EC]">
              Flavorful Chinese Specials
            </h4>
            <p className="text-xs sm:text-sm text-[#F8F4EC]/70 leading-relaxed">
              Customers frequently enjoy hot crispy starters like Chicken Lollipop, wok-tossed Hakka noodles, and seasoned gravies.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#161616] border border-[#282828] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C]">
              <Wallet className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-semibold text-[#F8F4EC]">
              Accessible Dining Value
            </h4>
            <p className="text-xs sm:text-sm text-[#F8F4EC]/70 leading-relaxed">
              With a reported price range of {restaurantInfo.priceRange}, Golden Bowl offers satisfying portions and friendly value for money.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#161616] border border-[#282828] space-y-3">
            <div className="w-10 h-10 rounded-xl bg-[#222222] border border-[#333333] flex items-center justify-center text-[#C9A45C]">
              <Users className="w-5 h-5" />
            </div>
            <h4 className="font-serif text-lg font-semibold text-[#F8F4EC]">
              Central Hajipur Location
            </h4>
            <p className="text-xs sm:text-sm text-[#F8F4EC]/70 leading-relaxed">
              Conveniently situated at Ramsagar Singh Complex along Kachahari Road, easily accessible for dine-in, takeout, and order enquiries.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
