/**
 * Types for Golden Bowl Restaurant Website & Owner Management
 */

export type MenuCategory =
  | 'All'
  | 'Popular Favorites'
  | 'Chinese Starters'
  | 'Noodles'
  | 'Fried Rice'
  | 'Chicken Specials'
  | 'Paneer Specials'
  | 'Main Course'
  | 'Breads'
  | 'Soups'
  | 'Beverages';

export interface MenuItem {
  id: string;
  name: string;
  category: MenuCategory;
  isVeg: boolean | null; // null if unverified
  price: number | null; // null if unconfigured by owner ("Contact us for price")
  description: string;
  isAvailable: boolean;
  isPopular?: boolean;
  image: string;
  spicyLevel?: 0 | 1 | 2 | 3;
}

export interface RestaurantInfo {
  name: string;
  tagline: string;
  category: string;
  address: string;
  landmark: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  phone: string;
  phoneRaw: string;
  plusCode: string;
  priceRange: string;
  ratingReference: number;
  reviewCountReference: number;
  ratingNote: string;
  openingHoursStatus: string;
  openingHoursNote: string;
  heroHeadline: string;
  heroSubheadline: string;
  storyHeadline: string;
  storyParagraph1: string;
  storyParagraph2: string;
  mapsSearchUrl: string;
  directionsUrl: string;
}

export interface OrderEnquiryItem {
  menuItemId: string;
  name: string;
  quantity: number;
  price: number | null;
}

export interface OrderEnquiry {
  id: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  preference: 'Pickup Enquiry' | 'Delivery Enquiry';
  notes?: string;
  items: OrderEnquiryItem[];
  status: 'New' | 'Contacted' | 'Confirmed' | 'Completed' | 'Cancelled';
}

export interface GalleryImage {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  caption: string;
}
